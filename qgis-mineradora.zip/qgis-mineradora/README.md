# Mapeamento da mineradora no QGIS — passo a passo

Repositório para executar, em ordem, o mapeamento do território de uma
**mineradora de calcário** no QGIS, na disciplina **Trabalho de Campo
Interdisciplinar em Geografia II** (3ª série, Bacharelado — UEMS).

A lógica do mapeamento vem do método de **Lemonnier** (Cap. 2, "From Field to
Files"): delimitar o território no gabinete **antes** de ir a campo, para que a
observação confirme ou refute uma hipótese espacial. O mapa é o ponto de
partida da técnica, não o ponto de chegada.

A pergunta que organiza tudo:

> Qual a diferença entre o **território de direito** (a poligonal que a empresa
> pode lavrar, no SIGMINE) e o **território de fato** (a área efetivamente
> perturbada, visível no satélite)?

---

## Os cinco passos

Rode os scripts em ordem, no **Console Python do QGIS** (não no terminal comum).
Cada script imprime o que fazer a seguir.

| Passo | Script | O que faz |
|---|---|---|
| 0 | `passo_0_verificar_ambiente.py` | confere QGIS e caminhos |
| 1 | `passo_1_projeto_e_satelite.py` | cria o projeto + satélite de fundo |
| 2 | `passo_2_territorio_de_direito.py` | carrega a poligonal SIGMINE (direito) |
| 3 | `passo_3_territorio_de_fato.py` | cria a camada para desenhar a pegada (fato) |
| 4 | `passo_4_pontos_do_campo.py` | carrega os pontos técnicos (GPS) |
| 5 | `passo_5_layout_e_exportar.py` | monta o layout e exporta PDF/PNG |

Tudo roda com **dados de exemplo** já incluídos — você vê o resultado antes de
ter os dados reais.

---

## Como rodar um script no QGIS (para iniciantes)

1. Abra o QGIS (baixe a versão LTR em qgis.org, se ainda não tem).
2. Menu **Complementos → Console Python** (ou `Ctrl+Alt+P`).
3. No console, clique em **"Mostrar editor"** (ícone de bloco de notas).
4. Abra o script do passo e clique em **Executar** (triângulo verde).

Antes de começar, abra `passo_0` e **ajuste a variável `RAIZ`** com o caminho
onde você descompactou/clonou esta pasta na sua máquina. Os outros scripts usam
o mesmo caminho.

---

## Antes do campo e depois do campo

Este mapeamento é feito **duas vezes**, como manda o método:

- **Antes** (gabinete): rode os passos 1 a 5 com os dados de exemplo/hipótese.
  Imprima o mapa. Ele mostra onde vocês *esperam* encontrar cada coisa.
- **Depois** (tratamento): troque os pontos de exemplo pelos reais do GPS
  (passo 4) e corrija a pegada desenhada (passo 3) com o que foi observado.
  Rode o passo 5 de novo. Agora o mapa mostra o que *de fato* está lá, e a
  diferença direito × fato vira o resultado do relatório.

---

## Estrutura

```
qgis-mineradora/
├── README.md                 ← este guia
├── scripts/                  ← os cinco passos (rodar no Console do QGIS)
├── dados/
│   ├── exemplo/              ← poligonal, pegada e pontos fictícios (rodam já)
│   └── reais/               ← você põe aqui os dados baixados/coletados
├── saidas/                   ← projeto .qgz e mapas exportados
└── docs/
    ├── 01_como_rodar.md      ← detalhe de como rodar no QGIS
    ├── 02_dados_reais.md     ← onde baixar SIGMINE, satélite, IBGE
    ├── 03_desenhar_pegada.md ← passo a passo do desenho manual (fato)
    └── CLAUDE.md             ← contexto para o Claude Code
```

---

## Divisão em dois grupos

- **Grupo A — território de direito e cadeia:** foca nos passos 2 e 4 (a
  poligonal e a sequência das operações).
- **Grupo B — território de fato e inventário:** foca no passo 3 (desenhar a
  pegada) e no inventário dos traços.

Na devolutiva, os dois grupos sobrepõem seus mapas e discutem a diferença.

---

## Precisa de ajuda para rodar?

O script do QGIS pode pedir ajustes de caminho ou versão na sua máquina. Abra
esta pasta no **Claude Code** e peça, por exemplo: *"execute o passo 2 no meu
QGIS e corrija os erros"*. O arquivo `docs/CLAUDE.md` já explica o contexto.
