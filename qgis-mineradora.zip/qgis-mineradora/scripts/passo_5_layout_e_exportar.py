# -*- coding: utf-8 -*-
"""
PASSO 5 — LAYOUT DE IMPRESSÃO E EXPORTAÇÃO
===========================================
Monta um layout A4 com o mapa, título, legenda e uma nota, e exporta em PDF e
PNG para a pasta saidas/. É o mapa que vai impresso ao campo (versão "antes")
e, depois, o mapa de resultados (versão "depois", já com os pontos e a pegada
corrigidos).

Roda com o que estiver carregado no projeto (satélite + direito + fato +
pontos). Rode os passos 1 a 4 antes deste.
"""
import os
from qgis.core import (QgsProject, QgsPrintLayout, QgsLayoutItemMap,
                       QgsLayoutItemLegend, QgsLayoutItemLabel, QgsLayoutPoint,
                       QgsLayoutSize, QgsUnitTypes, QgsLayoutExporter,
                       QgsRectangle)
from qgis.PyQt.QtGui import QFont

RAIZ = os.path.expanduser("~/qgis-mineradora")
SAIDA_PDF = os.path.join(RAIZ, "saidas", "mapa_mineradora.pdf")
SAIDA_PNG = os.path.join(RAIZ, "saidas", "mapa_mineradora.png")

proj = QgsProject.instance()
layout = QgsPrintLayout(proj)
layout.initializeDefaults()
layout.setName("Mapa da mineradora")

# --- mapa ---
mapa = QgsLayoutItemMap(layout)
mapa.attemptMove(QgsLayoutPoint(10, 22, QgsUnitTypes.LayoutMillimeters))
mapa.attemptResize(QgsLayoutSize(190, 160, QgsUnitTypes.LayoutMillimeters))
# extensão: usa a extensão atual da tela do QGIS
from qgis.utils import iface
if iface:
    mapa.setExtent(iface.mapCanvas().extent())
mapa.setLayers(list(proj.mapLayers().values()))
layout.addLayoutItem(mapa)

# --- título ---
titulo = QgsLayoutItemLabel(layout)
titulo.setText("Mineradora de calcário — território de direito x território de fato\n"
               "Trabalho de Campo II · Bacharelado em Geografia (UEMS)")
titulo.setFont(QFont("Arial", 13))
titulo.adjustSizeToText()
titulo.attemptMove(QgsLayoutPoint(10, 8, QgsUnitTypes.LayoutMillimeters))
layout.addLayoutItem(titulo)

# --- legenda ---
legenda = QgsLayoutItemLegend(layout)
legenda.setTitle("Legenda")
legenda.setLinkedMap(mapa)
legenda.attemptMove(QgsLayoutPoint(158, 185, QgsUnitTypes.LayoutMillimeters))
layout.addLayoutItem(legenda)

# --- nota de fonte ---
nota = QgsLayoutItemLabel(layout)
nota.setText("Fontes: poligonal SIGMINE/ANM; imagem Esri World Imagery; pontos coletados em campo (GPS). "
             "Elaboração dos discentes.")
nota.setFont(QFont("Arial", 7))
nota.adjustSizeToText()
nota.attemptMove(QgsLayoutPoint(10, 188, QgsUnitTypes.LayoutMillimeters))
layout.addLayoutItem(nota)

proj.layoutManager().addLayout(layout)

# --- exporta ---
os.makedirs(os.path.dirname(SAIDA_PDF), exist_ok=True)
exp = QgsLayoutExporter(layout)
exp.exportToPdf(SAIDA_PDF, QgsLayoutExporter.PdfExportSettings())
exp.exportToImage(SAIDA_PNG, QgsLayoutExporter.ImageExportSettings())
print(f"OK — mapa exportado:\n  {SAIDA_PDF}\n  {SAIDA_PNG}")
print("\nFim do passo a passo. Antes do campo: imprima este mapa.")
print("Depois do campo: troque os pontos (passo 4) pelos reais e corrija a pegada (passo 3), e rode este passo de novo.")
