# -*- coding: utf-8 -*-
"""
PASSO 1 — CRIAR O PROJETO E O MAPA DE FUNDO (SATÉLITE)
=======================================================
Cria um projeto novo do QGIS e adiciona uma imagem de satélite como fundo,
usando um serviço de tiles XYZ (não precisa baixar nada).

Isto é o gabinete de Lemonnier: montar a base sobre a qual vamos delimitar o
território ANTES de ir a campo.

Pré-requisito: passo 0 rodado com sucesso.
"""
import os
from qgis.core import QgsProject, QgsRasterLayer, QgsCoordinateReferenceSystem

RAIZ = os.path.expanduser("~/qgis-mineradora")   # ajuste igual ao passo 0

def add_xyz(nome, url):
    """Adiciona uma camada de tiles XYZ (satélite/mapa) ao projeto."""
    uri = f"type=xyz&url={url.replace('&','%26')}&zmax=19&zmin=0"
    layer = QgsRasterLayer(uri, nome, "wms")
    if layer.isValid():
        QgsProject.instance().addMapLayer(layer)
        print(f"OK — camada '{nome}' adicionada.")
    else:
        print(f"!! falhou ao adicionar '{nome}'. Verifique a conexão de internet.")
    return layer

# começa um projeto limpo
proj = QgsProject.instance()
proj.clear()
proj.setCrs(QgsCoordinateReferenceSystem("EPSG:4326"))

# satélite Esri (imagem) — bom para enxergar cava, pilhas e planta
esri = ("https://server.arcgisonline.com/ArcGIS/rest/services/"
        "World_Imagery/MapServer/tile/{z}/{y}/{x}")
add_xyz("Satélite (Esri World Imagery)", esri)

# opcional: um mapa de referência claro por cima (rótulos, estradas)
# osm = "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
# add_xyz("OpenStreetMap", osm)

# salva o projeto na pasta do repositório
destino = os.path.join(RAIZ, "saidas", "projeto_mineradora.qgz")
os.makedirs(os.path.dirname(destino), exist_ok=True)
proj.write(destino)
print(f"\nProjeto salvo em: {destino}")
print("Próximo: passo 2 — carregar a poligonal do território de direito.")
