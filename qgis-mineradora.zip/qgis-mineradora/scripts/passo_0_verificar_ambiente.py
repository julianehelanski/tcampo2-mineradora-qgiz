# -*- coding: utf-8 -*-
"""
PASSO 0 — VERIFICAR O AMBIENTE
================================
Rode este script PRIMEIRO, no Console Python do QGIS, para confirmar que
está tudo no lugar antes de começar o mapeamento.

COMO RODAR (vale para todos os scripts deste repositório):
  1. Abra o QGIS.
  2. Menu Complementos > Console Python  (ou Ctrl+Alt+P).
  3. No console, clique em "Mostrar editor".
  4. Abra este arquivo e clique em Executar (triângulo verde).

O que este passo faz: imprime a versão do QGIS, confirma que a pasta do
repositório foi encontrada e lista os dados de exemplo disponíveis.
"""
import os
from qgis.core import Qgis

# ---------------------------------------------------------------------------
# AJUSTE AQUI: caminho da pasta do repositório na SUA máquina.
# Ex. Windows: r"C:\\Users\\voce\\qgis-mineradora"
#     Linux/Mac: "/home/voce/qgis-mineradora"
RAIZ = os.path.expanduser("~/qgis-mineradora")
# ---------------------------------------------------------------------------

print("=" * 55)
print("QGIS versão:", Qgis.QGIS_VERSION)
print("Pasta do repositório:", RAIZ)
print("Existe?", os.path.isdir(RAIZ))
print("=" * 55)

if os.path.isdir(RAIZ):
    exemplo = os.path.join(RAIZ, "dados", "exemplo")
    print("Dados de exemplo encontrados:")
    for f in sorted(os.listdir(exemplo)):
        print("   -", f)
    print("\nTudo certo. Pode seguir para o passo 1.")
else:
    print("\n!! A pasta não foi encontrada. Ajuste a variável RAIZ acima com o")
    print("   caminho correto onde você descompactou/clonou o repositório.")
    print("   Se não souber o caminho, arraste a pasta para o terminal para vê-lo,")
    print("   ou peça ajuda ao Claude Code apontando este arquivo.")
