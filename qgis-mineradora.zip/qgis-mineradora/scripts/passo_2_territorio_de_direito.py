# -*- coding: utf-8 -*-
"""
PASSO 2 — TERRITÓRIO DE DIREITO: A POLIGONAL DO PROCESSO MINERÁRIO
===================================================================
Carrega a poligonal oficial da mineradora — o que a empresa PODE lavrar.
Com os dados de exemplo, usa um polígono fictício. Com dados reais, use o
shapefile do SIGMINE/ANM (ver docs/02_dados_reais.md).

Aplica um estilo de contorno vermelho, sem preenchimento, para a poligonal
ficar visível sobre o satélite sem tapar a imagem.
"""
import os
from qgis.core import (QgsProject, QgsVectorLayer, QgsFillSymbol)

RAIZ = os.path.expanduser("~/qgis-mineradora")

# ---- escolha a fonte: exemplo (padrão) ou real ----
USAR_EXEMPLO = True
if USAR_EXEMPLO:
    caminho = os.path.join(RAIZ, "dados", "exemplo", "poligonal_sigmine_exemplo.geojson")
else:
    # troque pelo seu shapefile baixado do SIGMINE:
    caminho = os.path.join(RAIZ, "dados", "reais", "SIGMINE_MS.shp")

layer = QgsVectorLayer(caminho, "Território de direito (SIGMINE)", "ogr")
if not layer.isValid():
    print(f"!! não consegui abrir: {caminho}")
else:
    # contorno vermelho, sem preenchimento
    simb = QgsFillSymbol.createSimple({
        "color": "255,0,0,0",            # preenchimento transparente
        "outline_color": "200,30,30,255",
        "outline_width": "0.8",
        "style": "no",                    # sem hachura
        "outline_style": "solid",
    })
    layer.renderer().setSymbol(simb)
    QgsProject.instance().addMapLayer(layer)
    print("OK — poligonal do território de direito carregada.")
    # zoom para a camada
    from qgis.utils import iface
    if iface:
        iface.mapCanvas().setExtent(layer.extent())
        iface.mapCanvas().refresh()
    # imprime a área declarada, se existir o campo
    for f in layer.getFeatures():
        campos = [fld.name() for fld in layer.fields()]
        if "area_ha" in campos:
            print(f"   área declarada no processo: {f['area_ha']} ha")
        break

print("Próximo: passo 3 — desenhar o território de fato sobre o satélite.")
