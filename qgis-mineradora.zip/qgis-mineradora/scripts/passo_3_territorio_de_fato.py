# -*- coding: utf-8 -*-
"""
PASSO 3 — TERRITÓRIO DE FATO: DESENHAR SOBRE O SATÉLITE
========================================================
Cria uma camada de polígonos EDITÁVEL para você (e os alunos) desenharem, à
mão, a pegada real da mineradora vista no satélite: a cava, a planta, as
pilhas, o pátio. Isto é o que ESTÁ lá, por oposição ao que a empresa PODE
lavrar (passo 2).

Este script prepara a camada e, opcionalmente, já carrega um exemplo pronto
de pegada para você ver como fica. O desenho de verdade é MANUAL — a parte
que ensina o olhar. Ver docs/03_desenhar_pegada.md para o passo a passo do
clique.
"""
import os
from qgis.core import (QgsProject, QgsVectorLayer, QgsField, QgsFields,
                       QgsFillSymbol)
from qgis.PyQt.QtCore import QVariant

RAIZ = os.path.expanduser("~/qgis-mineradora")

# ---- opção A: carregar o exemplo pronto (para ver o resultado) ----
CARREGAR_EXEMPLO = True
if CARREGAR_EXEMPLO:
    ex = os.path.join(RAIZ, "dados", "exemplo", "pegada_real_exemplo.geojson")
    lex = QgsVectorLayer(ex, "Território de fato (exemplo)", "ogr")
    if lex.isValid():
        simb = QgsFillSymbol.createSimple({
            "color": "255,190,60,90",       # laranja translúcido
            "outline_color": "200,120,20,255",
            "outline_width": "0.6",
        })
        lex.renderer().setSymbol(simb)
        QgsProject.instance().addMapLayer(lex)
        print("OK — pegada de exemplo carregada (laranja).")

# ---- opção B: criar uma camada NOVA, em branco, para você desenhar ----
campos = QgsFields()
campos.append(QgsField("classe", QVariant.String))     # cava, planta, pilha...
campos.append(QgsField("descricao", QVariant.String))

nova = QgsVectorLayer("Polygon?crs=EPSG:4326", "Território de fato (desenhar)", "memory")
nova.dataProvider().addAttributes(campos)
nova.updateFields()
simb2 = QgsFillSymbol.createSimple({
    "color": "255,190,60,60",
    "outline_color": "160,90,10,255",
    "outline_width": "0.6",
    "outline_style": "dash",
})
nova.renderer().setSymbol(simb2)
QgsProject.instance().addMapLayer(nova)
print("OK — camada 'Território de fato (desenhar)' criada e pronta para edição.")
print("\nAgora, no QGIS:")
print("  1. Selecione a camada 'Território de fato (desenhar)'.")
print("  2. Clique no lápis (Alternar edição).")
print("  3. Ferramenta 'Adicionar polígono' e desenhe sobre a cava, a planta, as pilhas.")
print("  4. A cada polígono, preencha o campo 'classe'.")
print("  5. Salve a edição (clique no lápis de novo).")
print("\nDetalhes em docs/03_desenhar_pegada.md")
