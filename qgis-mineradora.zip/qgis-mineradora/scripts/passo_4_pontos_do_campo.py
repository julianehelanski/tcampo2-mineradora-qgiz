# -*- coding: utf-8 -*-
"""
PASSO 4 — PONTOS TÉCNICOS (do campo, por GPS)
==============================================
Carrega os pontos coletados em campo — cada traço técnico de Lemonnier com
sua coordenada — a partir de um CSV. Antes do campo, usa os pontos de exemplo
(hipótese); depois do campo, troque pelo CSV com os pontos reais do GPS.

Aplica cor por tipo de traço (a mesma paleta dos diagramas da disciplina) e
rótulos com o nome de cada ponto.
"""
import os
from qgis.core import (QgsProject, QgsVectorLayer, QgsMarkerSymbol,
                       QgsCategorizedSymbolRenderer, QgsRendererCategory,
                       QgsPalLayerSettings, QgsTextFormat,
                       QgsVectorLayerSimpleLabeling)
from qgis.PyQt.QtGui import QFont

RAIZ = os.path.expanduser("~/qgis-mineradora")

# antes do campo: exemplo. depois: aponte para dados/reais/pontos_campo.csv
CSV = os.path.join(RAIZ, "dados", "exemplo", "pontos_tecnicos.csv")

CORES = {
    "extracao": "#E8A9AF", "beneficiamento": "#A9CE93", "calcinacao": "#9DB2E0",
    "rejeito": "#C4A5D6", "agua": "#8FBBB0", "logistica": "#E8CE8F",
}

uri = f"file://{CSV}?type=csv&xField=lon&yField=lat&crs=EPSG:4326"
layer = QgsVectorLayer(uri, "Pontos técnicos", "delimitedtext")
if not layer.isValid():
    print(f"!! não consegui abrir o CSV: {CSV}")
else:
    # simbologia categorizada por 'tipo'
    cats = []
    for tipo, cor in CORES.items():
        s = QgsMarkerSymbol.createSimple({"name": "circle", "color": cor,
                                          "outline_color": "#333333", "size": "3.5"})
        cats.append(QgsRendererCategory(tipo, s, tipo))
    layer.setRenderer(QgsCategorizedSymbolRenderer("tipo", cats))

    # rótulos com o nome
    lbl = QgsPalLayerSettings()
    lbl.fieldName = "nome"
    fmt = QgsTextFormat()
    fmt.setFont(QFont("Arial", 8))
    lbl.setFormat(fmt)
    layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl))
    layer.setLabelsEnabled(True)

    QgsProject.instance().addMapLayer(layer)
    n = layer.featureCount()
    print(f"OK — {n} pontos técnicos carregados e rotulados.")

print("Próximo: passo 5 — montar o layout de impressão e exportar o mapa.")
